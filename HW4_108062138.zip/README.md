# multimedia-hw4
- Q1:按下python檔的三角形，或是在Q1這個directory下面下`python 1.py`。output會存在`Q1/output`
- Q2:把`2.ipynb`丟到google colab，要記得附上bunny.obj。接著按下`run all`的按鈕。output會存在`Q2/output`